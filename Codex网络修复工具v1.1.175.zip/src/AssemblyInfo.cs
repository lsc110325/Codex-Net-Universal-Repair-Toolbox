﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Codex 网络修复工具")]
[assembly: AssemblyProduct("Codex 网络修复工具")]
[assembly: AssemblyDescription("一键修复 Codex / ChatGPT 桌面版 / Codex CLI 的网络连接问题")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyVersion("1.1.175.0")]
[assembly: AssemblyFileVersion("1.1.175.0")]
[assembly: ComVisible(false)]
